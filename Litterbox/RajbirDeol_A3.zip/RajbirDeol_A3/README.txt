*****************************************************
Rajbir Deol     0918139
CIS*4300        A3 - HFP
04/12/2020
*****************************************************

Hello friends and welcome to LitterBox, a semantic
video site dedicated to cats.


*****************************************************
Access the Prototype
*****************************************************

Link:
https://www.figma.com/proto/Y4C79jAUHRqjqDcs30QQH9/LitterBox?node-id=5%3A19&scaling=contain

Link is also in report, just click on Site on title
page, its underlined!

If for some reason the link does not work, the .fig
file is also included.


*****************************************************
Steps for Walkthrough
*****************************************************
Story 1: Navigation
  1.	Start on Home
  2.	Click Video on side nav bar
  3.	Click Channel on side nav bar
  4.	Click on any other side nav bar buttons to
      explore, ex. SIGN IN
  5.	Navigate back to home (can click on home inside
      nav or on  LitterBox icon in top nav)
  6.	Select a video from home page

Story 2: Watching Videos / Label Interaction
  1.	Find Video: cat fighting!! (1st video on homepage)
  2.	Click on any of circles on the tracker bar
  3.	Click between the circles to be directed to the
      different labeled panels of the video
  4.	Click on the play button to resume watching
      the video


*****************************************************
Image References
*****************************************************
- https://giphy.com/gifs/cheezburger-cat-wrestling-5xtDarq4PxZjQ1C1ww8
- https://www.youtube.com/watch?v=JVjDa0NmfeE&t=3s
- https://realgrumpycat.tumblr.com/
- https://kitty.tumblr.com/
- https://bongocatfanclub.tumblr.com/
- https://www.youtube.com/watch?v=7na_-LfGfpE
- https://www.youtube.com/watch?v=317jz-PU7Mg&t=156s
- https://www.youtube.com/watch?v=NsUWXo8M7UA
- https://www.youtube.com/watch?v=72NfSwCzFVE
- https://www.youtube.com/watch?v=J---aiyznGQ
- https://www.youtube.com/watch?v=7yLxxyzGiko
- https://www.ctvnews.ca/lifestyle/woman-yelling-at-cat-meme-his-name-is-smudge-he-s-from-ottawa-and-he-hates-salad-1.4691727
- https://www.scientificamerican.com/article/cats-recognize-their-own-names-even-if-they-choose-to-ignore-them/
- https://www.sciencemag.org/news/2019/02/reality-check-can-cat-poop-cause-mental-illness
- https://www.womansday.com/life/g32979681/cute-cat-photos/


*****************************************************
Note from Rajbir
*****************************************************
My favorite color is pink, and I admit that I may have gone overboard. Lol, pawlease don't dock mocks for it.
